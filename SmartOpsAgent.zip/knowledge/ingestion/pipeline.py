from document_parser.parser_factory import ParserFactory
from .chunker import TextChunker
from .metadata import enrich_chunk


class IngestionPipeline:

    def __init__(
        self,
        parser_factory: ParserFactory,
        chunker: TextChunker,
    ):
        self.parser_factory = parser_factory
        self.chunker = chunker

    def process(
        self,
        file_path: str,
        version: str = "latest",
    ):
        parser = self.parser_factory.get_parser(
            file_path
        )

        document = parser.parse(file_path)

        chunks = self.chunker.split(
            document_id=document.document_id,
            content=document.content,
            source=file_path,
            version=version,
        )

        for chunk in chunks:
            enrich_chunk(
                chunk,
                file_type=document.file_type,
                filename=document.filename,
            )

        return document, chunks