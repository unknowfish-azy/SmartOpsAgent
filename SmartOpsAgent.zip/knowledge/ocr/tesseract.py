import pytesseract

from PIL import Image


class TesseractOCR:

    def __init__(
        self,
        lang: str = "chi_sim+eng",
    ):
        self.lang = lang

    def extract_text(
        self,
        image_path: str,
    ) -> str:

        image = Image.open(image_path)

        return pytesseract.image_to_string(
            image,
            lang=self.lang,
        )