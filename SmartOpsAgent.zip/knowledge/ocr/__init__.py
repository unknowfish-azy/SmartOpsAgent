"""
SmartOpsAgent Knowledge OCR Module.

负责图片、扫描 PDF 等非结构化内容的文字识别。

支持：
- OCRService：OCR 统一抽象接口
- NoopOCR：未启用 OCR 时的占位实现
- TesseractOCR：基于 Tesseract 的 OCR 实现

OCR 是知识入库流程中的可选能力，不影响普通 TXT、Markdown、
可提取文本的 PDF 等文档的正常处理。
"""

from .base import OCRService
from .noop import NoopOCR
from .tesseract import TesseractOCR


__all__ = [
    "OCRService",
    "NoopOCR",
    "TesseractOCR",
]