"""
SmartOpsAgent Knowledge Document Parser Module.

负责不同类型运维知识文档的统一解析入口。

支持的文档类型包括：
- TXT
- LOG
- CONF
- YAML / YML
- JSON
- XML
- Markdown
- PDF
"""

__all__ = [
    "DocumentParser",
    "ParsedDocument",
    "TextParser",
    "MarkdownParser",
    "PdfParser",
    "ParserFactory",
]


def __getattr__(name: str):
    """
    延迟导入具体 Parser。

    当前目录名称 document-parser 含有连字符，
    不适合作为普通 Python package 直接使用标准 import。
    因此这里仅保留模块定义和导出声明，
    实际运行代码建议放在 document_parser/ 中。
    """
    raise AttributeError(
        f"module 'document-parser' has no attribute {name!r}"
    )