from sentence_transformers import SentenceTransformer


class SentenceTransformerEmbedding:

    def __init__(
        self,
        model_name: str,
    ):
        self.model = SentenceTransformer(
            model_name
        )

    def encode(
        self,
        texts: list[str],
    ) -> list[list[float]]:

        vectors = self.model.encode(
            texts,
            normalize_embeddings=True,
        )

        return vectors.tolist()

    def dimension(self) -> int:
        return self.model.get_sentence_embedding_dimension()