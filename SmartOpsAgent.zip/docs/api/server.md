# Server API

## 1. 接口定位

Server API 负责 SmartOpsAgent 中服务器资产的统一管理。

主要功能：

```text
服务器创建
服务器查询
服务器详情
服务器更新
服务器删除
服务器状态管理