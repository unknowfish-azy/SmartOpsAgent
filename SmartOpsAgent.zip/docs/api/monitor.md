# Monitor API

## 1. 接口定位

Monitor API 是 SmartOpsAgent 服务器监控模块的接口层，负责服务器运行指标的采集、写入、查询和状态判断。

主要监控：

```text
CPU
Memory
Disk
Network
Load Average