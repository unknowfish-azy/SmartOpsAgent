# Backend Architecture

## 1. 模块定位

Backend 是 SmartOpsAgent 的核心业务后端，负责：

```text
用户与权限
服务器资产
服务器监控
Agent 业务接口
系统配置
数据库访问