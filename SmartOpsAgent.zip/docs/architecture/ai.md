# AI Service Architecture

## 1. 模块定位

AI Service 是 SmartOpsAgent 的人工智能服务层，负责统一管理：

```text
LLM
RAG
Prompt
Chat
Model Provider
AI API