from typing import Any

from ..core.config import settings
from ..core.exceptions import LLMException


class LLMService:
    """
    LLM 统一服务接口。

    当前默认使用 mock。
    后续可接 Ollama、Qwen、OpenAI-compatible API 等。
    """

    async def generate(
        self,
        prompt: str,
        *,
        system_prompt: str | None = None,
        **kwargs: Any,
    ) -> str:

        provider = settings.llm_provider.lower()

        if provider == "mock":
            return self._mock_generate(
                prompt
            )

        if provider == "ollama":
            return await self._ollama_generate(
                prompt=prompt,
                system_prompt=system_prompt,
                **kwargs,
            )

        raise LLMException(
            f"暂不支持的 LLM Provider: {provider}"
        )

    @staticmethod
    def _mock_generate(
        prompt: str,
    ) -> str:

        return (
            "这是 SmartOpsAgent AI Service "
            "的开发阶段模拟回答。\n\n"
            "当前系统已经完成请求接收、RAG 编排和 "
            "LLM 服务接口预留。\n\n"
            f"用户问题：{prompt}"
        )

    async def _ollama_generate(
        self,
        prompt: str,
        system_prompt: str | None = None,
        **kwargs: Any,
    ) -> str:

        try:
            import httpx
        except ImportError as exc:
            raise LLMException(
                "未安装 httpx"
            ) from exc

        payload = {
            "model": settings.llm_model,
            "prompt": prompt,
            "stream": False,
        }

        if system_prompt:
            payload["system"] = system_prompt

        async with httpx.AsyncClient(
            timeout=settings.request_timeout
        ) as client:

            response = await client.post(
                (
                    f"{settings.llm_base_url}"
                    "/api/generate"
                ),
                json=payload,
            )

        if response.status_code != 200:
            raise LLMException(
                "Ollama 调用失败："
                f"{response.status_code}"
            )

        data = response.json()

        return data.get(
            "response",
            "",
        )