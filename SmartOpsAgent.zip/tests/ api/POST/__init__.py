"""
SmartOps POST API Tests.
"""