"""
Server POST API Tests.
"""