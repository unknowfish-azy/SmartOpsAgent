"""
Metrics GET API Tests.
"""