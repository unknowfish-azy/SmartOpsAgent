"""
SmartOps GET API Tests.
"""