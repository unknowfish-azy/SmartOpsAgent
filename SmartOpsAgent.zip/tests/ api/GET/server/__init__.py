"""
Server GET API Tests.
"""