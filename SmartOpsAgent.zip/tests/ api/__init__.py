"""
SmartOps API Tests.
"""