"""
AiAnalysis E2e Tests.
"""