"""
SmartOpsAgent Tests.

测试目录统一入口。

测试分层：

    tests/api
        API 接口测试

    tests/agent
        Agent / Harness 测试

    tests/e2e
        端到端测试

    tests/integration
        基础设施与服务集成测试
"""

__version__ = "0.1.0"