"""
MySQL Integration Tests.
"""