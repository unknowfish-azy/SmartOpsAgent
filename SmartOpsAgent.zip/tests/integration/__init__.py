"""
SmartOps Integration Tests.
"""