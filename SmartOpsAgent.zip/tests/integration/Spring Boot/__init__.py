"""
Spring Boot Integration Tests.
"""