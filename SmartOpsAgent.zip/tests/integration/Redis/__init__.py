"""
Redis Integration Tests.
"""