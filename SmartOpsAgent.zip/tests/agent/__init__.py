"""
SmartOps agent Tests.
"""