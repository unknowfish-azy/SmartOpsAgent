import { defineStore } from 'pinia'

export const useAppStore = defineStore(
    'app',
    {
        state: () => ({
            sidebarCollapsed: false,
            systemName: '智维Agent'
        }),

        actions: {
            toggleSidebar() {
                this.sidebarCollapsed =
                    !this.sidebarCollapsed
            }
        }
    }
)