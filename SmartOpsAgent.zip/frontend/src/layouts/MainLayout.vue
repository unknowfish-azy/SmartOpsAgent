<template>
  <div class="app-layout">

    <aside
        class="sidebar"
        :class="{
        collapsed: appStore.sidebarCollapsed
      }"
    >

      <div class="logo">
        <span class="logo-icon">智</span>

        <span
            v-if="!appStore.sidebarCollapsed"
            class="logo-text"
        >
          智维Agent
        </span>
      </div>

      <nav class="menu">

        <RouterLink to="/">
          <span>📊</span>
          <span v-if="!appStore.sidebarCollapsed">
            运维总览
          </span>
        </RouterLink>

        <RouterLink to="/servers">
          <span>🖥️</span>
          <span v-if="!appStore.sidebarCollapsed">
            服务器管理
          </span>
        </RouterLink>

      </nav>

    </aside>

    <div class="main-area">

      <header class="topbar">

        <button
            class="menu-button"
            @click="appStore.toggleSidebar()"
        >
          ☰
        </button>

        <div class="page-title">
          {{ appStore.systemName }}
        </div>

        <div class="topbar-right">
          <span>系统正常</span>
        </div>

      </header>

      <main class="content">
        <RouterView />
      </main>

    </div>

  </div>
</template>

<script setup>
import { useAppStore } from '../stores/app'

const appStore = useAppStore()
</script>