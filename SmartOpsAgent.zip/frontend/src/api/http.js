import axios from 'axios'

const http = axios.create({
    baseURL: import.meta.env.VITE_API_BASE_URL || 'http://localhost:8080',
    timeout: 10000,
    headers: {
        'Content-Type': 'application/json'
    }
})

http.interceptors.request.use(
    config => {
        return config
    },
    error => Promise.reject(error)
)

http.interceptors.response.use(
    response => {
        const result = response.data

        if (result && result.code !== 200) {
            return Promise.reject(
                new Error(result.message || '请求失败')
            )
        }

        return result
    },
    error => {
        const message =
            error.response?.data?.message ||
            error.message ||
            '网络请求失败'

        return Promise.reject(new Error(message))
    }
)

export default http