<template>
  <div>

    <div class="page-header">
      <div>
        <h1>运维总览</h1>
        <p>智维Agent运行状态</p>
      </div>
    </div>

    <div class="stat-grid">

      <el-card shadow="hover">
        <div class="stat-title">
          服务器总数
        </div>

        <div class="stat-value">
          {{ serverStore.list.length }}
        </div>
      </el-card>

      <el-card shadow="hover">
        <div class="stat-title">
          在线服务器
        </div>

        <div class="stat-value success">
          {{ serverStore.onlineCount }}
        </div>
      </el-card>

      <el-card shadow="hover">
        <div class="stat-title">
          异常服务器
        </div>

        <div class="stat-value warning">
          {{ serverStore.warningCount }}
        </div>
      </el-card>

    </div>

    <el-card
        class="server-card"
        shadow="never"
    >

      <template #header>
        <div class="card-header">
          <span>服务器概览</span>

          <el-button
              type="primary"
              link
              @click="goServers"
          >
            查看全部
          </el-button>
        </div>
      </template>

      <el-table
          v-loading="serverStore.loading"
          :data="serverStore.list"
          stripe
      >

        <el-table-column
            prop="name"
            label="服务器"
        />

        <el-table-column
            prop="host"
            label="地址"
        />

        <el-table-column
            prop="os"
            label="系统"
        />

        <el-table-column
            label="状态"
        >
          <template #default="{ row }">
            <ServerStatusTag
                :status="row.status"
            />
          </template>
        </el-table-column>

      </el-table>

    </el-card>

  </div>
</template>

<script setup>
import { onMounted } from 'vue'
import { useRouter } from 'vue-router'

import { useServerStore }
  from '../../stores/server'

import ServerStatusTag
  from '../../components/server/ServerStatusTag.vue'

const router = useRouter()
const serverStore = useServerStore()

function goServers() {
  router.push('/servers')
}

onMounted(() => {
  serverStore.fetchList()
})
</script>

<style scoped>
.page-header {
  margin-bottom: 20px;
}

.page-header h1 {
  margin: 0 0 6px;
}

.page-header p {
  margin: 0;
  color: var(--smart-muted);
}

.stat-grid {
  display: grid;
  grid-template-columns:
    repeat(3, minmax(0, 1fr));

  gap: 16px;
  margin-bottom: 20px;
}

.stat-title {
  color: var(--smart-muted);
  font-size: 14px;
}

.stat-value {
  margin-top: 10px;
  font-size: 32px;
  font-weight: 700;
}

.success {
  color: var(--smart-success);
}

.warning {
  color: var(--smart-warning);
}

.server-card {
  margin-top: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
}
</style>