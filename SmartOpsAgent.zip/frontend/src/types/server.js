export const ServerStatus = {
    ONLINE: 'ONLINE',
    OFFLINE: 'OFFLINE',
    WARNING: 'WARNING',
    UNKNOWN: 'UNKNOWN'
}