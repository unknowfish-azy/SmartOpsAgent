import {
    createRouter,
    createWebHistory
} from 'vue-router'

import MainLayout from '../layouts/MainLayout.vue'

import DashboardView
    from '../views/dashboard/DashboardView.vue'

import ServerListView
    from '../views/server/ServerListView.vue'

import ServerDetailView
    from '../views/server/ServerDetailView.vue'

import NotFoundView
    from '../views/error/NotFoundView.vue'

const routes = [
    {
        path: '/',
        component: MainLayout,
        children: [
            {
                path: '',
                name: 'Dashboard',
                component: DashboardView
            },
            {
                path: 'servers',
                name: 'ServerList',
                component: ServerListView
            },
            {
                path: 'servers/:id',
                name: 'ServerDetail',
                component: ServerDetailView,
                props: true
            }
        ]
    },

    {
        path: '/:pathMatch(.*)*',
        name: 'NotFound',
        component: NotFoundView
    }
]

const router = createRouter({
    history: createWebHistory(),
    routes
})

export default router