<template>
  <div class="empty">
    <div class="icon">📭</div>

    <div class="text">
      {{ text }}
    </div>
  </div>
</template>

<script setup>
defineProps({
  text: {
    type: String,
    default: '暂无数据'
  }
})
</script>

<style scoped>
.empty {
  padding: 40px;
  text-align: center;
  color: var(--smart-muted);
}

.icon {
  font-size: 32px;
  margin-bottom: 8px;
}

.text {
  font-size: 14px;
}
</style>