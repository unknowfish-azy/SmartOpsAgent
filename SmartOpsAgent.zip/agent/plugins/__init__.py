"""
SmartOps Harness Plugin Namespace.

插件类型包括：

- memory
- model
- sandbox
- scheduler
- session
- skill
- tool
- ui
- workflow
"""

__version__ = "0.1.0"