class ShellTool:

    name = "shell.execute"

    description = "执行受控 Shell 命令"

    risk_level = "HIGH"

    requires_approval = True

    ALLOWED_COMMANDS = {
        "whoami",
        "hostname",
        "uptime",
        "date",
    }

    def execute(
        self,
        command: str,
    ):

        command_name = (
            command.strip()
            .split()[0]
            if command.strip()
            else ""
        )

        if (
            command_name
            not in self.ALLOWED_COMMANDS
        ):
            raise PermissionError(
                "该 Shell 命令未进入安全白名单"
            )

        import subprocess

        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=10,
            check=False,
        )

        return {
            "return_code": result.returncode,
            "stdout": result.stdout,
            "stderr": result.stderr,
        }