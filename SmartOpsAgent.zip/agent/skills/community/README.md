# Community Skills

用于存放经过审核的社区技能。

建议结构：

```text
community/
└── skill-name/
    ├── SKILL.md
    ├── metadata.json
    └── references/