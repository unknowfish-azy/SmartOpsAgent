# Nginx Configuration Example

## 1. 场景

用于演示 SmartOps Agent 如何分析 Nginx 配置测试结果。

该示例不代表真实生产环境。

---

## 2. Configuration Test

执行：

```bash
nginx -t