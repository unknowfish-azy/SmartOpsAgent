"""
Nginx Troubleshooting Skill Examples.

该目录用于存放 Nginx 故障排查的示例输入、
示例输出以及分析样例。

examples 主要用于：

- Skill 学习
- Prompt 示例
- Agent 推理参考
- 单元测试数据
- Demo 演示

这里的示例数据必须是脱敏数据。
禁止放入：

- 真实服务器 IP
- 密码
- Token
- Cookie
- 私钥
- 数据库凭证
- 生产环境敏感日志
"""

__version__ = "1.0.0"

__all__ = []