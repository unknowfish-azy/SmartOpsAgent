# Nginx Safe Operations Reference

## 1. 文档目的

本文件定义 SmartOps Agent 在 Nginx 运维场景中的安全操作规范。

核心目标：

```text
证据优先
+
只读优先
+
最小权限
+
风险分级
+
人工审批
+
受控执行
+
执行验证
+
完整审计