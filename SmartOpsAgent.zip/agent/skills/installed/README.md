# Installed Skills

这里存放已经安装的Skill。

建议：

```text
installed/
├── nginx-troubleshooting/
├── mysql-troubleshooting/
├── docker-troubleshooting/
└── kubernetes-troubleshooting/