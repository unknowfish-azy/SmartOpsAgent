"""
SmartOps Installed Skills.

这里存放已经安装到本地 Harness 的 Skills。

Installed Skill 与 Plugin 的区别：

Skill：
    方法 / 知识 / SOP

Plugin：
    能力 / Tool / Runtime Integration
"""

__version__ = "0.1.0"