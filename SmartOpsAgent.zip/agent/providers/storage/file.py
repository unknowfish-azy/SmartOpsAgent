import json
from pathlib import Path
from typing import Any


class FileStorage:

    def __init__(
        self,
        root: str | Path,
    ) -> None:
        self.root = Path(root)

        self.root.mkdir(
            parents=True,
            exist_ok=True,
        )

    def save(
        self,
        key: str,
        value: dict[str, Any],
    ) -> None:

        target = self.root / f"{key}.json"

        target.write_text(
            json.dumps(
                value,
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )

    def load(
        self,
        key: str,
    ) -> dict[str, Any] | None:

        target = self.root / f"{key}.json"

        if not target.exists():
            return None

        return json.loads(
            target.read_text(
                encoding="utf-8"
            )
        )