# Prometheus

Prometheus负责指标采集与告警规则。

当前模板重点关注：

- Node CPU
- Node Memory
- Node Disk
- Backend健康
- AI Service健康