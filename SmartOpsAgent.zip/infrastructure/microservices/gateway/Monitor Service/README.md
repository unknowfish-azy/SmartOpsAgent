# Gateway Route - Monitor Service

该目录保存网关到 **Monitor Service** 的路由模板。

默认原则：认证/授权在网关与目标服务双重校验；高风险Agent操作不能因为经过Gateway而绕过Policy。
