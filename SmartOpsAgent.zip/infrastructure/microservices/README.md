## 服务边界

```text
Gateway
 ├─ Auth Service
 ├─ Monitor Service
 ├─ Knowledge Service
 ├─ AI Service
 ├─ Agent Service
 └─ Ops Service