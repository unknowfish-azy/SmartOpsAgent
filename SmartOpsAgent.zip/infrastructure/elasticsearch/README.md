# Elasticsearch

用于知识、日志和审计数据的全文检索增强。项目当前RAG核心仍可使用Python内存/向量方案，本目录用于后续扩展。
