# Elasticsearch 索引初始化

建议索引：

- `smartops-knowledge`：知识文档与Chunk
- `smartops-logs`：结构化运维日志
- `smartops-audit`：Agent审计事件