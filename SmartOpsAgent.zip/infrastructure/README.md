# Infrastructure

`infrastructure/` 保存智维Agent的可选基础设施配置与部署模板。MVP阶段不要求一次性启用全部组件，当前推荐的基础运行链路仍然是：

```text
MySQL + Redis + Backend + AI Service + Frontend