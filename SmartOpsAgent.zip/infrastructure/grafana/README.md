# Grafana

Grafana用于展示Prometheus采集的服务器和服务指标。

## 目录

```text
dashboards/      Dashboard JSON
datasources/    数据源配置
provisioning/   Dashboard自动加载配置