# Kafka

Kafka用于高吞吐事件流，例如：

- `smartops.alerts`：监控告警事件
- `smartops.agent.tasks`：Agent任务事件
- `smartops.audit`：审计事件
- `smartops.knowledge.events`：知识入库/更新事件