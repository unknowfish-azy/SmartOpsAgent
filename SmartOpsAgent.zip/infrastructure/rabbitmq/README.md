# RabbitMQ

RabbitMQ用于任务型、可靠投递型消息，例如：

- Agent执行任务
- 审批事件
- 异步知识处理
- 通知事件
