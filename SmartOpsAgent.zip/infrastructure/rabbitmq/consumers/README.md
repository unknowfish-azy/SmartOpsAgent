# Consumers

Consumer处理建议：

- 手动Ack
- 幂等
- 重试上限
- 死信队列
- 记录request_id/event_id
