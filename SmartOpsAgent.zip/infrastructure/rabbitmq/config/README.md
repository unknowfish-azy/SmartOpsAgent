# RabbitMQ config

该目录保存服务端配置模板。生产环境应结合容器/Operator管理用户、TLS和权限。