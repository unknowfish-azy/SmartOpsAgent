# Service Mesh

Service Mesh用于未来微服务规模扩大后的：

- 服务间流量治理
- mTLS
- 超时/重试
- 可观测性
- 灰度发布
- 访问策略