## 结构

```text
namespace/     Namespace
configmap/     非敏感配置
deployment/    Deployment
service/       Service
hpa/           HPA
ingress/       Ingress
secret/        Secret模板