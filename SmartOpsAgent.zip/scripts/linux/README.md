# Linux Scripts

Linux 脚本用于服务器监控 Agent 的基础能力。

当前：

```text
collect-metrics.sh
install-monitor.sh