# SmartOpsAgent Scripts

本目录保存 SmartOpsAgent 项目在开发、测试、部署和服务器监控过程中使用的辅助脚本。

## 目录结构

```text
scripts/
├── README.md
│
├── common/
│   ├── init-db.sql
│   └── README.md
│
├── linux/
│   ├── README.md
│   ├── collect-metrics.sh
│   └── install-monitor.sh
│
└── windows/
    ├── README.md
    ├── check-env.ps1
    └── start-dev.ps1