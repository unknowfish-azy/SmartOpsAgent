# Windows Scripts

用于 SmartOpsAgent Windows 本地开发环境。

## check-env.ps1

检查：

```text
Java
Maven
Node.js
npm
Python
Docker
Git