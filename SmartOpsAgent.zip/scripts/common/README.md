# Common Scripts

本目录保存 SmartOpsAgent 项目中跨平台使用的公共初始化脚本和基础数据脚本。

## 目录结构

```text
common/
├── init-db.sql
└── README.md