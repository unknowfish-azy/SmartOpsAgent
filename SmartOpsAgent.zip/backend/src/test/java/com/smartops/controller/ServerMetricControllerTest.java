package com.smartops.controller;

import com.smartops.service.ServerMetricService;
import com.smartops.vo.ServerMetricVO;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(ServerMetricController.class)
class ServerMetricControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ServerMetricService metricService;

    @Test
    void getLatestMetricShouldSuccess()
            throws Exception {

        ServerMetricVO vo =
                ServerMetricVO.builder()
                        .id(1L)
                        .serverId(1L)
                        .cpuUsage(35.5)
                        .memoryUsage(52.2)
                        .diskUsage(61.3)
                        .build();

        when(metricService.latest(1L))
                .thenReturn(vo);

        mockMvc.perform(
                        get("/api/servers/1/metrics/latest")
                )
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(200))
                .andExpect(jsonPath("$.data.serverId").value(1))
                .andExpect(jsonPath("$.data.cpuUsage").value(35.5));
    }
}