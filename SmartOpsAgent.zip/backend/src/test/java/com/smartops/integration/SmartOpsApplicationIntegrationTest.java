package com.smartops.integration;

import com.smartops.SmartOpsApplication;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = SmartOpsApplication.class)
class SmartOpsApplicationIntegrationTest {

    @Test
    void contextLoads() {
    }
}