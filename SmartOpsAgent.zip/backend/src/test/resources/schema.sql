DROP TABLE IF EXISTS server_metric;
DROP TABLE IF EXISTS server;

CREATE TABLE server (
                        id BIGINT AUTO_INCREMENT PRIMARY KEY,
                        name VARCHAR(100) NOT NULL,
                        host VARCHAR(255) NOT NULL,
                        port INT NOT NULL,
                        os VARCHAR(50),
                        status VARCHAR(20) NOT NULL,
                        description VARCHAR(500),
                        created_at TIMESTAMP NOT NULL,
                        updated_at TIMESTAMP NOT NULL
);

CREATE TABLE server_metric (
                               id BIGINT AUTO_INCREMENT PRIMARY KEY,
                               server_id BIGINT NOT NULL,
                               cpu_usage DOUBLE NOT NULL,
                               memory_usage DOUBLE NOT NULL,
                               disk_usage DOUBLE NOT NULL,
                               network_in DOUBLE,
                               network_out DOUBLE,
                               load_average DOUBLE,
                               status VARCHAR(20) NOT NULL,
                               collected_at TIMESTAMP NOT NULL,

                               CONSTRAINT fk_metric_server
                                   FOREIGN KEY (server_id)
                                       REFERENCES server(id)
                                       ON DELETE CASCADE
);

CREATE INDEX idx_server_metric_server_time
    ON server_metric(server_id, collected_at);