package com.smartops.module.server;

public enum ServerStatus {

    ONLINE,
    OFFLINE,
    WARNING,
    UNKNOWN
}