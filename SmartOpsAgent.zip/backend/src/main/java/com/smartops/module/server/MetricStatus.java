package com.smartops.module.server;

public enum MetricStatus {

    NORMAL,
    WARNING,
    CRITICAL
}