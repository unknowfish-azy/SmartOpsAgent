package com.smartops.service.impl;

import com.smartops.dto.MetricCreateRequest;
import com.smartops.entity.ServerEntity;
import com.smartops.entity.ServerMetricEntity;
import com.smartops.exception.BusinessException;
import com.smartops.mapper.ServerMetricMapper;
import com.smartops.mapper.ServerMapper;
import com.smartops.module.server.MetricStatus;
import com.smartops.module.server.ServerStatus;
import com.smartops.service.ServerMetricService;
import com.smartops.vo.ServerMetricVO;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
public class ServerMetricServiceImpl implements ServerMetricService {

    private final ServerMapper serverRepository;
    private final ServerMetricMapper metricRepository;

    @Override
    public ServerMetricVO create(Long serverId,
                                 MetricCreateRequest request) {

        ServerEntity server = serverRepository.findById(serverId)
                .orElseThrow(() -> new BusinessException("服务器不存在"));

        MetricStatus status = calculateStatus(
                request.getCpuUsage(),
                request.getMemoryUsage(),
                request.getDiskUsage()
        );

        ServerMetricEntity metric = ServerMetricEntity.builder()
                .server(server)
                .cpuUsage(request.getCpuUsage())
                .memoryUsage(request.getMemoryUsage())
                .diskUsage(request.getDiskUsage())
                .networkIn(request.getNetworkIn())
                .networkOut(request.getNetworkOut())
                .loadAverage(request.getLoadAverage())
                .status(status)
                .build();

        server.setStatus(
                status == MetricStatus.NORMAL
                        ? ServerStatus.ONLINE
                        : ServerStatus.WARNING
        );

        serverRepository.save(server);

        return toVO(metricRepository.save(metric));
    }

    @Override
    @Transactional(readOnly = true)
    public ServerMetricVO latest(Long serverId) {

        if (!serverRepository.existsById(serverId)) {
            throw new BusinessException("服务器不存在");
        }

        return metricRepository
                .findTopByServer_IdOrderByCollectedAtDesc(serverId)
                .map(this::toVO)
                .orElseThrow(() -> new BusinessException("暂无监控数据"));
    }

    @Override
    @Transactional(readOnly = true)
    public List<ServerMetricVO> latestList(Long serverId) {

        if (!serverRepository.existsById(serverId)) {
            throw new BusinessException("服务器不存在");
        }

        return metricRepository
                .findTop100ByServer_IdOrderByCollectedAtDesc(serverId)
                .stream()
                .map(this::toVO)
                .toList();
    }

    private MetricStatus calculateStatus(Double cpu,
                                         Double memory,
                                         Double disk) {

        if (cpu >= 90 || memory >= 90 || disk >= 90) {
            return MetricStatus.CRITICAL;
        }

        if (cpu >= 80 || memory >= 80 || disk >= 80) {
            return MetricStatus.WARNING;
        }

        return MetricStatus.NORMAL;
    }

    private ServerMetricVO toVO(ServerMetricEntity entity) {

        return ServerMetricVO.builder()
                .id(entity.getId())
                .serverId(entity.getServer().getId())
                .cpuUsage(entity.getCpuUsage())
                .memoryUsage(entity.getMemoryUsage())
                .diskUsage(entity.getDiskUsage())
                .networkIn(entity.getNetworkIn())
                .networkOut(entity.getNetworkOut())
                .loadAverage(entity.getLoadAverage())
                .status(entity.getStatus())
                .collectedAt(entity.getCollectedAt())
                .build();
    }
}