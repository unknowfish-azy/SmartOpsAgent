package com.smartops.security;

public final class SecurityConstants {

    private SecurityConstants() {
    }

    public static final String API_PREFIX = "/api";

    public static final String LOGIN_PATH = "/api/auth/login";

    public static final String TOKEN_PREFIX = "Bearer ";
}