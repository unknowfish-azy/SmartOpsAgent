# SmartOpsAgent Evaluation Data

本目录用于保存智维Agent的评测基准数据和评测数据格式定义。

## 目录结构

```text
evaluation/
├── OpsBench-v1.json
├── OpsBench-v2.json
├── schema.json
└── README.md