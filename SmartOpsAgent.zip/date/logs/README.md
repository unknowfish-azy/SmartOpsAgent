# SmartOpsAgent Logs

用于保存开发、测试、实验过程中产生的日志。

目录：

```text
logs/
├── agent/
├── retrieval/
├── llm/
├── audit/
└── evaluation/