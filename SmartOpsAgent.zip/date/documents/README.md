# SmartOpsAgent Knowledge Documents

本目录用于保存智维Agent知识库使用的原始运维文档。

这些文档是 Knowledge 模块进行文档解析、切块、Embedding、检索和证据生成的基础数据源。

---

## 1. 当前文档

当前目录包含以下运维知识文档：

```text
Docker运维手册.pdf
MySQL故障案例.pdf
Nginx运维手册.pdf
Ubuntu运维手册.pdf