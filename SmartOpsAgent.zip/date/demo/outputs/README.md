# Demo Outputs

本目录保存比赛 Demo 执行后的输出结果。

可以保存：

```text
Agent 最终回答
Evidence
Citation
Trust Score
Tool Execution Result
Audit Record