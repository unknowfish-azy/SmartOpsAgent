# SmartOpsAgent Data

`data` 用于保存智维Agent开发、测试、演示和评测过程中产生的非代码数据。

主要包括：

- 运维知识文档
- Demo 场景
- OpsBench 评测数据
- Agent 执行日志
- 检索实验日志
- LLM 调用日志
- 审计记录
- 评测实验结果

---

## 目录结构

```text
data/
├── demo/
├── documents/
├── evaluation/
└── logs/